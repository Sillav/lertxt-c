export interface PokemonTypes {
    nome: String,
    tipo: [String],
    status: [String],
    numero_dex: Number,
    altura: Number,
    peso: Number,
    moves: [String]
}