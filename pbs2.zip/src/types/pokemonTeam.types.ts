export interface PokemonTeamTypes {
    trainerName: String,
    team: [{
        nome: String
    }]
}