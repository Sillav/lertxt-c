import { Router } from "express";
import PokemonController from "./src/pokemon.controller"

const routes = Router();

//routes.get("/getPokeApi", PokemonController.readPokeApi);
//routes.get("/filterPokeApi", PokemonController.filterPokemons);
//routes.get("/getPokemonsMongoDB", PokemonController.getPokemonsMongoDB);


routes.post("/writePokemonsJSON", PokemonController.writePokemonsJSONandSaveMongoDB); // QUESTÃO 1
routes.post("/writeTiposPokemonsJSON", PokemonController.writeTiposPokemonsJSON);     // QUESTÃO 2
routes.get("/findByType/:tipo", PokemonController.findPokemonsByTypeMongoDB);         // QUESTÃO 4
routes.get("/findByName/:nome", PokemonController.findPokemonsByNameMongoDB);         // QUESTÃO 5
routes.get("/findByDex/:dex", PokemonController.findPokemonsByDexMongoDB);            // QUESTÃO 6

export default routes;