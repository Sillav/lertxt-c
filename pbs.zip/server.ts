import app from "./app";

function main() {
    try {
        app.listen(3001, "localhost", async () => {
            console.log("SERVIDOR INICIADO NA PORTA 3001")
        });
    } catch (erro) {
        console.error("ERRO: "+erro);
    }
}

main()